// rafce -> shortcut to create component and export
import { BrowserRouter, Routes, Route } from "react-router-dom";
import React from "react";
import Home from "./pages/home/Home";
import About from "./pages/about/About";
import Contact from "./pages/contact/Contact";
import Signup from "./pages/signup/signup"
import NotFound from "./pages/notFound/NotFound";
import Plans from "./pages/plans/Plans";
import Food from "./pages/food/food";
import Setting from "./pages/setting/setting"
import Trainers from "./pages/trainers/Trainers";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Login from "./pages/Login/Login"

const App = () => {
	return (
		<BrowserRouter>
			<Navbar />
			<Routes>
				<Route index element={<Home />} />
				<Route path="about" element={<About />} />
				<Route path="contact" element={<Contact />} />
				<Route path="plans" element={<Plans />} />
				<Route path ="Food" element={<Food />}/>
				<Route path="Setting" element={<Setting />} />
				<Route path="Signup" element={<Signup />} />
				<Route path="Login" element={<Login />} />
				<Route path="trainers" element={<Trainers />} />
				<Route path="*" element={<NotFound />} />
			</Routes>
			<Footer />
		</BrowserRouter>
	);
};

export default App;