import React from "react";
import "./home.css";
import MainHeader from "../../components/MainHeader";
import FAQs from "../../components/FAQs";
import CaloriesTracker from "../../components/CaloriesTracker";

// import Footer from "../../components/Footer";

const Home = () => {
	return (
		<>
			<MainHeader />
			<CaloriesTracker/>
			<FAQs />
			
			{/* <Footer /> comment this out so footer wount be double */}
		</>
	);
};

export default Home;
