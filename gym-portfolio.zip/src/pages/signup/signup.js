import React, { useState } from 'react';
import axios from 'axios';
import './signup.css';

const Signup = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignUp = async (e) => {
    e.preventDefault();

    try {
      // Make a POST request to your backend signup endpoint
      const response = await axios.post('http://localhost:5000/auth/register', {
        username,
        email,
        password,
      });

      console.log('Sign Up successful:', response.data);

      // Handle your success scenario (redirect, show a success message, etc.)
    } catch (error) {
      console.error('Sign Up failed:', error.response.data);
      // Handle your error scenario (show an error message, etc.)
    }
  };

  return (
    <div className="signup-container">
      <form onSubmit={handleSignUp} className="signup-form">
        <h1>Sign Up</h1>
        <div className="form-group">
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit">Sign Up</button>
        <p>
        Already have an account? <a href="/login">Log In</a>
      </p>
      </form>

     
    </div>
  );
};

export default Signup;
