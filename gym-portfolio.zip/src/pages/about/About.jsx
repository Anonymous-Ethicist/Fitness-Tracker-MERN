import React from "react";
import "./about.css";
import Header from "../../components/Header";
import HeaderImage from "../../images/header_bg_1.jpg";
import StoryImage from "../../images/about1.jpg";
import VisionImage from "../../images/about2.jpg";
import MissionImage from "../../images/about3.jpg";

const About = () => {
	return (
		<>
			<Header title="About us" image={HeaderImage}>
				
"PES University Gym is your fitness destination, dedicated to fostering a healthy lifestyle. Empower yourself with state-of-the-art facilities and expert guidance for an unparalleled fitness journey."
			</Header>
			<section className="about__story">
				<div className="container about__story-container">
					<div className="about__section-image">
						<img src={StoryImage} alt="OurStoryImage" />
					</div>
					<div className="about__section-content">
						<h1>The Beginning of the Journey</h1>
						<p>
						In the dimly lit corners of doubt, John found himself at the threshold of a
						 transformative journey. His sedentary lifestyle had taken its toll, and the monotony of his days
						 left him yearning for change. One day, he walked through the doors of the 
						PES University Gym, a haven pulsating with the energy of ambition. It was 
						a decisive step into the unknown, a commitment to rewriting his story with sweat, determination, and resilience.
						</p>
						<p>
						The initial days were a symphony of sore muscles and self-doubt. Yet, within the challenge, John
						 discovered his reservoir of inner strength. The gym became a metaphorical battlefield, and each 
						 rep and drop of sweat was a victory over complacency. The trainers at PES University Gym became 
						 mentors, guiding him through the labyrinth of fitness, imparting not only physical prowess but 
						 mental fortitude. The camaraderie with fellow enthusiasts turned strangers into allies, sharing
						  in the collective journey of transformation.
						</p>
						<p>
						As weeks turned into months, the metamorphosis was undeniable. John's body sculpted itself into 
						a testament of discipline, echoing the power of consistency. The gym, once an unfamiliar territory, 
						became a second home. Beyond the physical changes, the mental metamorphosis was profound. 
						The once elusive confidence now radiated from him. PES University Gym was not merely a space 
						for exercise; it was a catalyst for personal evolution. John's journey was not just about 
						lifting weights but lifting the limits of his own potential, proving that within the echoes
						 of each rep lies the power to sculpt not just a body, but a life reborn with strength and 
						 resilience.
						</p>
					</div>
				</div>
			</section>

			<section className="about__vision">
				<div className="container about__vision-container">
					<div className="about__section-content">
						<h1>Our Vision</h1>
						<p>
						At PES University, we envision a dynamic and holistic student experience, 
						where our state-of-the-art gymnasium serves as a cornerstone for physical 
						well-being and personal growth. Fostering a culture of fitness, the PES
						 University gym aims to be a vibrant hub, inspiring students to embrace 
						 a healthy lifestyle. Through cutting-edge facilities and expert guidance, 
						 we aspire to empower our students to achieve their fitness goals, ensuring 
						 they graduate not only academically enriched but physically resilient.
						</p>
						
					</div>
					<div className="about__section-image">
						<img src={VisionImage} alt="VisionImage" />
					</div>
				</div>
			</section>

			<section className="about__mission">
				<div className="container about__mission-container">
					<div className="about__section-image">
						<img src={MissionImage} alt="VisionImage" />
					</div>
					<div className="about__section-content">
						<h1>Our Mission</h1>
						<p>
						"At PES University, our mission is to foster holistic student development, 
						including physical well-being. The gym is an integral part of this commitment,
						 providing a space for students to cultivate a healthy lifestyle. We aim to
						  inspire a culture of fitness, resilience, and self-discipline, ensuring 
						  that our students graduate not only academically accomplished but also 
						  equipped with the vitality to lead active and balanced lives."
						</p>
						
					</div>
				</div>
			</section>
		</>
	);
};

export default About;
