// Login.js
import React, { useState } from 'react';
import axios from 'axios';
import './login.css'; // You can add your styling here

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      // Make a POST request to your backend login endpoint
      const response = await axios.post('http://localhost:5000/auth/login', {
        username,
        password,
      });

      console.log('Login successful:', response.data);

      // Handle your success scenario (redirect, show a success message, etc.)
    } catch (error) {
      console.error('Login failed:', error.response.data);
      // Handle your error scenario (show an error message, etc.)
    }
  };

  return (
    <div className="login-container">
      <form onSubmit={handleLogin}>
      <h2>Login</h2>
        <div className="form-group">
          <label>Username:</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit">Login</button>
        {/* Optionally, you can add a link to navigate to the signup page */}
      <p>
        Don't have an account? <a href="/signup">Sign Up</a>
      </p>
      </form>

      
    </div>
  );
};

export default Login;
