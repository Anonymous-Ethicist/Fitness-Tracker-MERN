import React, { useState } from 'react';
import axios from 'axios';
import './food.css';

const SearchPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [gramsConsumed, setGramsConsumed] = useState(0);

  const handleSearch = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/foods?query=${searchTerm}`);
      setSearchResults(response.data); // Assuming the response is an array of food objects
    } catch (error) {
      console.error('Error fetching search results:', error);
    }
  };

  const handleGramsChange = (e) => {
    const gramsValue = e.target.value;
    setGramsConsumed(gramsValue);
  };

  const handleFoodConsumption = async (foodName) => {
    try {
      await axios.post(`http://localhost:5000/stats/fopo`, {
        foodName,
        quantity: gramsConsumed,
      });
      // Optionally, you can fetch and update the UI with the latest daily stats
      // after posting the food consumption data
    } catch (error) {
      console.error('Error posting food consumption:', error);
    }
  };

  return (
    <div className="search-container">
      <h1>Search for a food</h1>
      <div className="search-bar">
        <input
          type="text"
          placeholder="Search for food items..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        <button onClick={handleSearch}>Search</button>
      </div>

      {searchResults.length > 0 && (
        <div className="search-results">
          <h2>Search Results:</h2>
          <ul>
            {searchResults.map((food) => (
              <li key={food._id}>
                <div className="dis">
                  <p>Name: {food.name}</p>
                  <p>Calories: {food.calories}</p>
                  <p>Protein: {food.protein}</p>
                  <p>
                    Grams Consumed:
                    <input
                      type="number"
                      value={gramsConsumed}
                      onChange={handleGramsChange}
                      min="0"
                    />
                    <button onClick={() => handleFoodConsumption(food.name)}>Log</button>
                  </p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default SearchPage;
