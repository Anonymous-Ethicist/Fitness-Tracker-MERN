import React, { useState } from 'react';
import './setting.css'; // Import the CSS file for styling

const SettingPage = () => {
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [goal, setGoal] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform actions with the user input (e.g., submit to a server, update state, etc.)
    console.log('User Input:', { height, weight, goal });
  };

  return (
    <div className="setting-container">
      <h1>Settings</h1>
      <form onSubmit={handleSubmit} className="setting-form">
        <label>
          Height (cm):
          <input
            type="number"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
          />
        </label>

        <label>
          Weight (kg):
          <input
            type="number"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
          />
        </label>

        <label>
          Goal:
          <select value={goal} onChange={(e) => setGoal(e.target.value)}>
            <option value="lose">Lose Weight</option>
            <option value="maintain">Maintain Weight</option>
            <option value="gain">Gain Weight</option>
            <option value="Composition">Body Recomposition</option>
          </select>
        </label>

        <button type="submit">Save</button>
      </form>
    </div>
  );
};

export default SettingPage;
