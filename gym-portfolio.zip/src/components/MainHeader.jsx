import React from "react";
import { Link } from "react-router-dom";
import Image from "../images/main_header.png";

const MainHeader = () => {
	return (
		<header className="main__header">
			<div className="container main__header-container">
				<div className="main__header-left">
					<h4>#100DaysOfWorkout</h4>
					<h1>Join The Legends of the Fitness World</h1>
					<p>
						"Welcome to a sanctuary of strength, where each drop of sweat is a 
						testament to your journey. At our gym, we redefine limits and trans
						cend boundaries. Embrace the burn, relish the challenge, for 
						within every repetition lies the transformation you seek. Our 
						community breathes motivation, inspiring each member to push 
						beyond yesterday's achievements. Here, we celebrate resilience, 
						discipline, and the relentless pursuit of a better you. Unleash
						your potential, sculpt your story, and let the echoes of 
						determination reverberate through every workout. This isn't
						just a gym; it's the crucible of your fitness evolution. 
						Elevate your life, one rep at a time."
					</p>
					<Link to="/plans" className="btn lg">
						Get Started
					</Link>
				</div>
				<div className="main__header-right">
					<div className="main__header-circle"></div>
					<div className="main__header-image">
						<img src={Image} alt="MainHeaderImage" />
					</div>
				</div>
			</div>
		</header>
	);
};

export default MainHeader;
