import React from 'react';

const CaloriesTracker = () => {
  return (
    <div className="calories-container">
      <div className="calories-circle">
        <div className="calories-content">
          <div className="calories-number">1200</div>
          <div className="calories-label">Calories</div>
        </div>
      </div>
      <div className="side-sections">
        <div className="food-section">
          <h2>Food</h2>
          <p>Explore nutritious meals to fuel your body and achieve your fitness goals.</p>
          <ul>
            <li>Vegetables</li>
            <li>Lean Proteins</li>
            <li>Whole Grains</li>
          </ul>
        </div>
        <div className="exercise-section">
          <h2>Exercise</h2>
          <p>Engage in heart-pumping workouts to boost your metabolism and enhance overall well-being.</p>
          <ul>
            <li>Cardiovascular exercises</li>
            <li>Strength training</li>
            <li>Flexibility exercises</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default CaloriesTracker;
